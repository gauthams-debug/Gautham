<?php
// PHP will handle the form data. For this example, we'll just display a confirmation.
// In a real application, you would connect to a database here.

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $name = isset($_POST['name']) ? htmlspecialchars($_POST['name']) : 'Guest';
    $email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : 'N/A';
    $address = isset($_POST['address']) ? htmlspecialchars($_POST['address']) : 'N/A';
    $payment = isset($_POST['payment']) ? htmlspecialchars($_POST['payment']) : 'N/A';

    // Simulate order processing
    $order_id = uniqid(); // Generate a unique ID for the order

    // Here you would add code to:
    // 1. Validate the data
    // 2. Connect to a database
    // 3. Save the order details
    // 4. Send a confirmation email to the user
    // 5. Redirect the user to a "thank you" page

    // For this example, we will just output a confirmation message
    $confirmation_message = "Thank you, $name! Your order has been placed.
    A confirmation email will be sent to $email.
    Your Order ID is: $order_id";

    // You can customize the HTML response page
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Order Confirmed</title>
        <style>
            body { font-family: sans-serif; text-align: center; padding: 50px; background-color: #f5f8fa; }
            .confirmation-box { max-width: 600px; margin: auto; padding: 40px; border-radius: 12px; background-color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            h1 { color: #00897b; }
            pre { text-align: left; background-color: #eee; padding: 20px; border-radius: 8px; }
            a { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #00897b; color: white; text-decoration: none; border-radius: 50px; }
        </style>
    </head>
    <body>
        <div class='confirmation-box'>
            <h1>Order Confirmed!</h1>
            <p>Your order has been successfully processed.</p>
            <pre>$confirmation_message</pre>
            <a href='index.html'>Continue Shopping</a>
        </div>
    </body>
    </html>
    ";

} else {
    // If someone tries to access this page directly without submitting the form
    echo "Access Denied.";
}
?>