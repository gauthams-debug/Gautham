document.addEventListener('DOMContentLoaded', function() {
    let cart = [];

    // Get DOM elements
    const cartCountElement = document.getElementById('cartCount');
    const openModalBtn = document.getElementById('openModalBtn');
    const closeOrderModalBtn = document.getElementById('closeOrderModalBtn');
    const orderModal = document.getElementById('orderModal');
    const welcomeModal = document.getElementById('welcomeModal');
    const welcomeBtn = document.getElementById('welcomeBtn');
    const modalCartItems = document.getElementById('modalCartItems');
    const modalCartTotal = document.getElementById('modalCartTotal');
    const orderForm = document.getElementById('orderForm');
    const contactForm = document.getElementById('contactForm');
    const continueShoppingBtn = document.getElementById('continueShoppingBtn');

    // Show welcome modal on page load
    setTimeout(() => {
        welcomeModal.classList.add('active');
    }, 500);

    welcomeBtn.addEventListener('click', () => {
        welcomeModal.classList.remove('active');
    });

    // Add to Cart Functionality
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productName = productCard.getAttribute('data-name');
            const productPrice = parseFloat(productCard.getAttribute('data-price'));
            const productImage = productCard.querySelector('img').src;

            const existingItem = cart.find(item => item.name === productName);

            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({
                    name: productName,
                    price: productPrice,
                    quantity: 1,
                    image: productImage
                });
            }

            updateCartDisplay();
            alert(`${productName} added to cart!`);
        });
    });

    function updateCartDisplay() {
        cartCountElement.textContent = cart.reduce((total, item) => total + item.quantity, 0);

        modalCartItems.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            modalCartItems.innerHTML = '<p style="text-align: center; color: var(--text-gray); margin-top: 20px;">Your cart is empty.</p>';
        } else {
            cart.forEach((item, index) => {
                const itemElement = document.createElement('div');
                itemElement.classList.add('cart-item');
                itemElement.innerHTML = `
                    <div class="cart-item-info">
                        <img src="${item.image}" alt="${item.name}">
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.name}</div>
                            <span>Qty: ${item.quantity}</span>
                        </div>
                    </div>
                    <div class="cart-item-price">$${(item.quantity * item.price).toFixed(2)}</div>
                    <button class="remove-item-btn" data-index="${index}">Remove</button>
                `;
                modalCartItems.appendChild(itemElement);
                total += item.quantity * item.price;
            });
        }

        modalCartTotal.textContent = `Total: $${total.toFixed(2)}`;

        // Add event listeners for new remove buttons
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.addEventListener('click', function() {
                const itemIndex = this.getAttribute('data-index');
                cart.splice(itemIndex, 1);
                updateCartDisplay();
            });
        });
    }

    // Open/Close Modals
    openModalBtn.addEventListener('click', () => {
        orderModal.classList.add('active');
        updateCartDisplay();
    });
    closeOrderModalBtn.addEventListener('click', () => {
        orderModal.classList.remove('active');
    });

    // New: Continue Shopping button
    continueShoppingBtn.addEventListener('click', () => {
        orderModal.classList.remove('active');
    });

    // Contact Form Submission (handled via JS)
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('contact-name').value;
        alert(`Thank you for your message, ${name}! We will get back to you shortly.`);
        contactForm.reset();
    });
});